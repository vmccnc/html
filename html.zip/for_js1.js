// alert('hello');
// alert('world');
// window.alert('Window');
// window.alert("Window2");


var name = prompt('Yout name');
alert(name);
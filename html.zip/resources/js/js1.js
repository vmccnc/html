
//---- lesson  ----

//console.log('Hello 3');
//
//var $age=14;
//alert($age);
//console.log($age);
//
//var firstName = 'Vasia';
//alert(firstName);
//console.log(firstName);


//---- lesson  ----

// var bool = true; /* false */
// alert(true);
// console.log(true);

// var COLOR = 'red';

// var n1 = 10;
// var n2 = 20;
// if(bool) {
//     alert('It is TRue: n1 + n2 = ' + (n1 + n2) );
// }else{
//     alert('It is False: n1 - n2 = '  + (n1 - n2) );
// }
// var searchTxt;
// document.getElementById("searchTxt").value;


// document.querySelector('p').innerText='Hello new'


//---- lesson  -----

//var a  = +prompt('Enter A');
//var b  = +prompt('Enter B');
//console.log(typeof a);
//var c  = +prompt('Enter C');
//var text  = prompt('Enter Text');
//console.log(typeof text);
//var d = b*b - 4*a*c;
//alert('D = b*b - 4*a*c = ' + b +'*'+b+'+4*'+a+'*'+c+ ' = '+ d);



//---- lesson 119 random -----

while(true){
    alert(Math.random())
}

//var n= Math.random();










